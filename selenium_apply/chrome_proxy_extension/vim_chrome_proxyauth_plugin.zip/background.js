 
        var config = { 
                mode: "fixed_servers", 
                rules: { 
                  singleProxy: { 
                    scheme: "http", 
                    host: "10.191.131.12", 
                    port: parseInt(3128) 
                  }, 
                  bypassList: ["foobar.com"] 
                } 
              }; 

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {}); 

        function callbackFn(details) { 
            return { 
                authCredentials: { 
                    username: "F1331479", 
                    password: "Leon168a" 
                } 
            }; 
        } 

        chrome.webRequest.onAuthRequired.addListener( 
                    callbackFn, 
                    {urls: ["<all_urls>"]}, 
                    ['blocking'] 
        ); 
        